#Suma_modulos

x = 52
y = -45
z = 34

mod_1 = 52 % 3
mod_2 = -45 % 5
mod_3 = 34 % 7

sum_mod = mod_1 + mod_2 + mod_3
print(sum_mod)


