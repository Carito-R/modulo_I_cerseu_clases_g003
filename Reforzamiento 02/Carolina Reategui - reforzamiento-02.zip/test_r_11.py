# Edad elevado a la potencia

caro = 31 ** 5

print(caro)

car_2 = caro / 10

print(car_2)
print(type(car_2))
mod_c = car_2 % 3
print(mod_c)
