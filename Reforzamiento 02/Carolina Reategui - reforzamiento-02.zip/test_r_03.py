#Suma de variables string y entero

p = "Peso: "
w = 61
print(p + str(w))  # → "Edad: 25"
