# Almacenamiento de informacion

nombre = "Luna"
nom_prod = "crema de peinar"
precio_unit = 62.5
cantidad = 2
total_pago = 125

print("Buen día {}, el detalle de su compra es el siguiente: - Producto: "" {}, - Precio unitario: {}, - Cantidad: {}, - Total a pagar: {}".format(nombre, nom_prod, precio_unit, cantidad, total_pago))
