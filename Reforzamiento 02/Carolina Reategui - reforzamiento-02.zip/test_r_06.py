# Media
import statistics

a = 36.5
b = 47.2
c = 30.4
d = 50.0
e = 44.4

med = (a + b + c + d + e) / 5


print("Media {}".format(med))
print(type(med))
