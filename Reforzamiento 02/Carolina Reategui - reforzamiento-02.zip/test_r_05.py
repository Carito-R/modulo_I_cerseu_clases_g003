# Módulo, condicional

remuneracion = 3555

if remuneracion % 2 == 0:
    print("La remuneracion es par: {}".format(remuneracion))
else:
    print("La remumeracion es impar: {}".format(remuneracion))
