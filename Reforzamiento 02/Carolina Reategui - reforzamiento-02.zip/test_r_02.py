#Multiplicación y resta
Enteros: int

a = 50
b = a * 10 - 10

print(a)
print(b)

f = float(b)
print(type(f))
