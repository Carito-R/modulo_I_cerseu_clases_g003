# Datos flotantes

c = 5.452687

print("El valor de mi variable c modificada es: {}".format(f" {c:.1f}"))
print("El valor de mi variable c modificada es: {}".format(f" {c:.2f}"))
print("El valor de mi variable c modificada es: {}".format(f" {c:.4f}"))
