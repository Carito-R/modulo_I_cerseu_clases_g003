"""
Reforzamiento
String: str
"""

mi_saludo = "HI CAROLINA REATEGUI"
nombre_completo = "Carolina Reategui Reategui"

print(mi_saludo)
print(nombre_completo)

print("Tipo de dato de mi variable 'mi_saludo' es {}".format(type(mi_saludo)))
print("Tipo de dato de mi variable 'nombre_completo' es {}".format(type(nombre_completo)))
