# Operacion

e = 5

exp = (pow(e,6))
print(exp)

mult_1 = exp * 2
rest_1 = exp - mult_1

print(rest_1)
