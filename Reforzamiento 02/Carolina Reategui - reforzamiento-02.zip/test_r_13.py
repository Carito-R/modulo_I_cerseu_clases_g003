# Temperatura

C = 30
C_2 = 22
F = (C * 9)/5 + 32
F_2 = (C_2 * 9)/5 + 32

print(F)

print("La temperatura en °C:{}".format(C))
print("La temperatura en °C:{}".format(C_2))
print("Temperatura en Fahrenheit:{}".format(f" {F:.2f}"))
print("Temperatura en Fahrenheit:{}".format(f" {F_2:.2f}"))
