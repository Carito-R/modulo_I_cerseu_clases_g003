#Lista de datos

dato_1 = ["Caro", "Maria", "Sol", "Diana"]
dato_2 = []
list_1 = True
list_2 = False

if list_1:
    print("La lista contiene datos".format(dato_1))

if list_2:
    print("La lista contiene datos".format(dato_2))